/* ============================================================
 * فلزیاب پالسی STM32F105 + ماژول HC-05 — کد نهایی آماده کپی
 * ============================================================
 * سیم‌بندی نهایی (حالت کار عادی):
 *
 *   HC-05 VCC (5V)  --->  5V برد
 *   HC-05 GND       --->  GND برد
 *   HC-05 TXD       --->  PA10 (USART1_RX میکرو)
 *   HC-05 RXD       --->  مقسم ولتاژ ---> PA9 (USART1_TX میکرو)
 *
 *   ⚠️ پایه RXD ماژول HC-05 تحمل 5V مستقیم را ندارد!
 *   با دو مقاومت مقسم بساز:
 *     PA9 (TX میکرو، 3.3V) ---[1K]---+---[2K]--- GND
 *                                     |
 *                                به RXD ماژول
 *
 *   پایه EN/KEY و دکمه روی ماژول فقط برای حالت AT لازم است (کار عادی نه).
 *
 * تنظیم CubeMX:
 *   USART1, Mode=Asynchronous, Baud=9600, Word=8, Parity=None, Stop=1
 *   NVIC: USART1 global interrupt را فعال کن (اختیاری، برای دریافت)
 * ============================================================ */

#include "usart.h"
#include <stdio.h>
#include <string.h>

extern UART_HandleTypeDef huart1;   // همان USART1 متصل به HC-05

/* کدهای فلز — عیناً با اپ اندروید یکی است. دست نزن! */
#define METAL_IRON     0
#define METAL_GOLD     1
#define METAL_SILVER   2
#define METAL_COPPER   3
#define METAL_BRONZE   4
#define METAL_ALU      5
#define METAL_UNKNOWN  9

/* ---- ارسال یک پکت به موبایل (هر 200 تا 300ms صدا بزن) ---- */
void HC05_SendPacket(int vdi, int sig, int depth_cm, int size_cm, int metal)
{
    char buf[128];
    if (sig < 0) sig = 0;
    if (sig > 1000) sig = 1000;
    if (depth_cm < 0) depth_cm = 0;
    if (depth_cm > 600) depth_cm = 600;
    if (size_cm < 0) size_cm = 0;

    int len = snprintf(buf, sizeof(buf),
        "{\"vdi\":%d,\"sig\":%d,\"depth\":%d,\"size\":%d,\"metal\":%d}\n",
        vdi, sig, depth_cm, size_cm, metal);

    if (len > 0)
        HAL_UART_Transmit(&huart1, (uint8_t*)buf, (uint16_t)len, 100);
}

/* ---- مثال اتصال به متغیرهای خودت (در main.c) ----
 *
 *  // این‌ها را با متغیرهای واقعی دستگاهت جایگزین کن:
 *  extern int g_proximity_1_1000;  // همان خط حساسیت LCD (1 تا 1000)
 *  extern int g_vdi;               // عدد VDI
 *  extern int g_depth_cm;          // عمق 20 تا 600 (وگرنه 0)
 *  extern int g_size_cm;           // قطر تخمینی (وگرنه 0)
 *  extern int g_metal;             // از تفکیک صوتی/حذف آهن: 0..5 یا 9
 *
 *  در حلقه while(1):
 *
 *    HC05_SendPacket(g_vdi, g_proximity_1_1000, g_depth_cm, g_size_cm, g_metal);
 *    HAL_Delay(250);
 *
 *  اگر حذف آهن فعال و هدف آهن بود: metal = METAL_IRON بفرست
 *  (اپ خودش آن را قرمز نشان می‌دهد).
 */

/* ---- تست سلامت HC-05 (اختیاری، با debugger) ----
 * اگر گوشی وصل نمی‌شود، این را یک بار صدا بزن و با اسکوپ/ترمینال
 * ببین آیا ماژول جواب می‌دهد. در حالت عادی (نه AT) باید "OK" برگردد
 * به شرطی که قبلاً جفت شده باشد. تست اصلی AT در حالت AT-Mode است. */
uint8_t HC05_IsAlive(void)
{
    const char *cmd = "AT\r\n";
    uint8_t resp[16] = {0};
    HAL_UART_Transmit(&huart1, (uint8_t*)cmd, 4, 100);
    // منتظر جواب "OK" (فقط در حالت AT-Mode جواب می‌دهد)
    if (HAL_UART_Receive(&huart1, resp, 2, 500) == HAL_OK)
        return (resp[0] == 'O' && resp[1] == 'K');
    return 0;
}
