package com.metaldetector.bt

import android.Manifest
import android.annotation.SuppressLint
import android.app.AlertDialog
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothSocket
import android.content.pm.PackageManager
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.*
import kotlin.concurrent.thread
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {

    companion object {
        // UUID استاندارد SPP برای HC-05 / HC-06
        val SPP_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
        const val REQ_BT = 101
        // کد نوع فلز: 0=آهن 1=طلا 2=نقره 3=مس 4=برنز 5=آلومینیوم 9=ناشناخته
        // حد پایین سیگنال برای تشخیص وجود هدف
        const val TARGET_THRESHOLD = 60
    }

    private lateinit var tvStatus: TextView
    private lateinit var tvRaw: TextView
    private lateinit var tvVdi: TextView
    private lateinit var tvSignal: TextView
    private lateinit var barSignal: ProgressBar
    private lateinit var tvDepth: TextView
    private lateinit var barDepth: ProgressBar
    private lateinit var scene: DetectorSceneView
    private lateinit var graph: SignalGraphView
    private lateinit var btnConnect: Button
    private lateinit var btnDisconnect: Button
    private lateinit var btnDemo: Button
    private lateinit var swSound: Switch
    private lateinit var swVibrate: Switch

    private var btAdapter: BluetoothAdapter? = null
    private var socket: BluetoothSocket? = null
    private var readThread: Thread? = null
    private var running = false
    private var demoMode = false
    private var demoTimer: Timer? = null
    private var tone: ToneGenerator? = null
    private var lastBeep = 0L
    private val ui = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvStatus = findViewById(R.id.tvStatus)
        tvRaw = findViewById(R.id.tvRaw)
        tvVdi = findViewById(R.id.tvVdi)
        tvSignal = findViewById(R.id.tvSignal)
        barSignal = findViewById(R.id.barSignal)
        tvDepth = findViewById(R.id.tvDepth)
        barDepth = findViewById(R.id.barDepth)
        scene = findViewById(R.id.scene)
        graph = findViewById(R.id.graph)
        btnConnect = findViewById(R.id.btnConnect)
        btnDisconnect = findViewById(R.id.btnDisconnect)
        btnDemo = findViewById(R.id.btnDemo)
        swSound = findViewById(R.id.swSound)
        swVibrate = findViewById(R.id.swVibrate)

        val mgr = getSystemService(BluetoothManager::class.java)
        btAdapter = mgr?.adapter
        try { tone = ToneGenerator(AudioManager.STREAM_MUSIC, 80) } catch (_: Exception) {}

        // در ابتدا هیچ هدفی نمایش داده نمی‌شود
        scene.update(false, 9, 0, 0, false)

        btnConnect.setOnClickListener { pickAndConnect() }
        btnDisconnect.setOnClickListener { disconnect() }
        btnDemo.setOnClickListener { toggleDemo() }
    }

    // ---------- انتخاب دستگاه و اتصال ----------
    private fun hasBtPermission(): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            return checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED &&
                checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED
        }
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
    }

    private fun askBtPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            ActivityCompat.requestPermissions(this,
                arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN), REQ_BT)
        } else {
            ActivityCompat.requestPermissions(this,
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), REQ_BT)
        }
    }

    @SuppressLint("MissingPermission")
    private fun pickAndConnect() {
        if (!hasBtPermission()) { askBtPermission(); return }
        val adapter = btAdapter
        if (adapter == null) { toast("بلوتوث روی این گوشی پشتیبانی نمی‌شود"); return }
        if (!adapter.isEnabled) { toast("ابتدا بلوتوث گوشی را روشن کنید"); return }

        val paired: Set<BluetoothDevice> = try { adapter.bondedDevices ?: emptySet() } catch (_: Exception) { emptySet() }
        if (paired.isEmpty()) {
            AlertDialog.Builder(this)
                .setTitle("دستگاهی Pair نشده")
                .setMessage("ابتدا در تنظیمات بلوتوث گوشی، ماژول HC-05 فلزیاب را Pair کنید (رمز معمولاً 1234 یا 0000 است)، بعد دوباره تلاش کنید.")
                .setPositiveButton("فهمیدم", null).show()
            return
        }
        val list = paired.toList()
        val names = list.map { "${it.name ?: "بدون نام"}\n${it.address}" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("انتخاب ماژول بلوتوث فلزیاب")
            .setItems(names) { _, which -> connectTo(list[which]) }
            .setNegativeButton("لغو", null).show()
    }

    @SuppressLint("MissingPermission")
    private fun connectTo(device: BluetoothDevice) {
        setStatus("در حال اتصال به ${device.name} ...")
        btnConnect.isEnabled = false
        thread {
            try {
                try { socket?.close() } catch (_: Exception) {}
                val s = device.createRfcommSocketToServiceRecord(SPP_UUID)
                btAdapter?.cancelDiscovery()
                s.connect()
                socket = s
                running = true
                ui.post {
                    setStatus("✅ متصل: ${device.name}")
                    btnDisconnect.isEnabled = true
                    btnConnect.isEnabled = false
                    toast("متصل شد")
                }
                startReader()
            } catch (e: Exception) {
                ui.post {
                    setStatus("❌ خطا در اتصال: ${e.message}")
                    btnConnect.isEnabled = true
                }
            }
        }
    }

    private fun startReader() {
        readThread?.interrupt()
        readThread = thread {
            try {
                val br = BufferedReader(InputStreamReader(socket!!.inputStream, Charsets.UTF_8))
                while (running) {
                    val line = br.readLine() ?: break
                    val clean = line.trim()
                    if (clean.isEmpty()) continue
                    ui.post {
                        tvRaw.text = "داده خام: $clean"
                        handleLine(clean)
                    }
                }
            } catch (e: Exception) {
                if (running) ui.post { setStatus("ارتباط قطع شد: ${e.message}"); btnConnect.isEnabled = true; btnDisconnect.isEnabled = false }
            }
        }
    }

    fun disconnect() {
        running = false
        try { socket?.close() } catch (_: Exception) {}
        socket = null
        setStatus("وضعیت: قطع")
        btnConnect.isEnabled = true
        btnDisconnect.isEnabled = false
    }

    // ---------- حالت دمو ----------
    private fun toggleDemo() {
        if (!demoMode) {
            demoMode = true
            btnDemo.text = "⏸ توقف دمو"
            setStatus("حالت دمو فعال (بدون سخت‌افزار)")
            var t = 0
            demoTimer = Timer()
            demoTimer?.scheduleAtFixedRate(object : TimerTask() {
                override fun run() {
                    t++
                    // شبیه‌سازی: هدف گاهی وجود دارد و گاهی نه
                    val sig = (500 + 480 * Math.sin(t / 6.0)).toInt().coerceIn(0, 1000)
                    val vdi = 72 + (Math.sin(t / 9.0) * 8).roundToInt()
                    val depth = (60 + Math.sin(t / 12.0) * 40 + 60).roundToInt()
                    val metal = if (sig > 700) 1 else if (sig > 350) 3 else 9
                    val size = if (sig > 700) 50 else 8
                    val json = JSONObject()
                    json.put("vdi", vdi); json.put("sig", sig)
                    json.put("depth", depth); json.put("size", size); json.put("metal", metal)
                    val line = json.toString()
                    ui.post { tvRaw.text = "داده خام (دمو): $line"; handleLine(line) }
                }
            }, 0, 300)
        } else {
            demoMode = false
            demoTimer?.cancel(); demoTimer = null
            btnDemo.text = "▶ حالت دمو (بدون سخت‌افزار)"
            setStatus("وضعیت: قطع")
            scene.update(false, 9, 0, 0, false)
        }
    }

    // ---------- پردازش یک خط داده ----------
    private fun handleLine(line: String) {
        try {
            // فرمت مورد انتظار: {"vdi":72,"sig":850,"depth":145,"size":18,"metal":1}
            val j = JSONObject(line)
            val vdi = j.optInt("vdi", 0)
            val sig = j.optInt("sig", j.optInt("signal", 0)).coerceIn(0, 1000)
            val depth = j.optInt("depth", 0)
            val size = j.optInt("size", 0)
            val metal = j.optInt("metal", j.optInt("type", 9))
            render(vdi, sig, depth, size, metal)
        } catch (_: Exception) {
            // فرمت متنی ساده: VDI=72 SIG=850 DEPTH=145 SIZE=18 METAL=1
            try {
                fun num(key: String): Int =
                    Regex("$key\\s*[:=]\\s*(-?\\d+)").find(line)?.groupValues?.get(1)?.toIntOrNull() ?: 0
                val metal = if (line.contains("METAL")) num("METAL") else 9
                render(num("VDI"), num("SIG").coerceIn(0, 1000), num("DEPTH"), num("SIZE"), metal)
            } catch (_: Exception) { /* نادیده */ }
        }
    }

    private fun render(vdi: Int, sig: Int, depth: Int, sizeCm: Int, metal: Int) {
        tvSignal.text = sig.toString()
        barSignal.progress = sig
        tvVdi.text = "VDI: $vdi"
        graph.push(sig)

        // صحنه: شکل و رنگ فلز، خط‌کش عمق، نوع و ابعاد
        val hasTarget = sig >= TARGET_THRESHOLD
        val estimated = hasTarget && sizeCm <= 0
        val effSize = if (sizeCm > 0) sizeCm else when {
            sig < 250 -> 5    // تخمین از روی قدرت سیگنال: هدف کوچک
            sig < 650 -> 15
            else -> 35
        }
        scene.update(hasTarget, metal, depth, if (hasTarget) effSize else 0, estimated)

        // عمق ۲۰ تا ۶۰۰
        if (depth in 20..600) {
            tvDepth.text = "$depth cm"
            barDepth.progress = depth
        } else {
            tvDepth.text = "--- cm"
            barDepth.progress = 0
        }

        // بوق متناسب با سیگنال
        if (swSound.isChecked && sig > 80) {
            val now = SystemClock.uptimeMillis()
            if (now - lastBeep > (1100 - sig).coerceAtLeast(120)) {
                lastBeep = now
                try { tone?.startTone(ToneGenerator.TONE_PROP_BEEP, 120) } catch (_: Exception) {}
            }
        }
        // لرزش برای طلا/نقره
        if (swVibrate.isChecked && (metal == 1 || metal == 2) && sig > 500) {
            try {
                val vib = getSystemService(Vibrator::class.java)
                if (Build.VERSION.SDK_INT >= 26) vib?.vibrate(VibrationEffect.createOneShot(120, VibrationEffect.DEFAULT_AMPLITUDE))
                else @Suppress("DEPRECATION") vib?.vibrate(120)
            } catch (_: Exception) {}
        }
    }

    private fun setStatus(s: String) { tvStatus.text = s }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    override fun onDestroy() {
        super.onDestroy()
        demoTimer?.cancel()
        running = false
        try { socket?.close() } catch (_: Exception) {}
        try { tone?.release() } catch (_: Exception) {}
    }
}
