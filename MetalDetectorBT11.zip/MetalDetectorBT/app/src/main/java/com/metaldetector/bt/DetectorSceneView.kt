package com.metaldetector.bt

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View
import kotlin.math.cos
import kotlin.math.sin

/**
 * صحنهٔ اصلی صفحه:
 *  - سمت چپ: شخصی با فلزیاب که روی زمین جارو می‌کند
 *  - وسط: زیر خط زمین، شکل و رنگ فلز (اندازه و عمق متناسب)
 *  - سمت راست: میله/خط‌کش عمودی از سطح زمین تا هدف با عدد عمق
 *  - بالا سمت راست: نوع فلز و ابعاد فلز
 */
class DetectorSceneView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    private val dp = resources.displayMetrics.density

    private var hasTarget = false
    private var metalCode = 9
    private var depthCm = 0
    private var sizeCm = 0
    private var sizeEstimated = false

    private fun paint(color: Int, style: Paint.Style = Paint.Style.FILL, strokeW: Float = 0f) =
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color
            this.style = style
            this.strokeWidth = strokeW
        }

    private val bgPaint = Paint().apply { color = Color.parseColor("#0B0F12") }
    private val soilPaint = Paint().apply { color = Color.parseColor("#1F1712") }
    private val groundPaint = paint(Color.parseColor("#8D6E63"), Paint.Style.STROKE, 2.5f * dp)
    private val personPaint = paint(Color.parseColor("#90A4AE"), Paint.Style.STROKE).apply {
        strokeCap = Paint.Cap.ROUND
    }
    private val personFill = paint(Color.parseColor("#90A4AE"))
    private val shaftPaint = paint(Color.parseColor("#CFD8DC"), Paint.Style.STROKE).apply {
        strokeCap = Paint.Cap.ROUND
    }
    private val coilPaint = paint(Color.parseColor("#FFB300"), Paint.Style.STROKE)
    private val scanPaint = paint(Color.parseColor("#33FFB300"))
    private val rulerPaint = paint(Color.parseColor("#B0BEC5"), Paint.Style.STROKE, 2f * dp)
    private val dashPaint = paint(Color.parseColor("#757575"), Paint.Style.STROKE, 1.5f * dp).apply {
        pathEffect = DashPathEffect(floatArrayOf(8f * dp, 6f * dp), 0f)
    }
    private val labelPaint = paint(Color.parseColor("#B0BEC5")).apply {
        textSize = 11f * dp; textAlign = Paint.Align.RIGHT
    }
    private val depthLabelPaint = paint(Color.parseColor("#26C6DA")).apply {
        textSize = 14f * dp; textAlign = Paint.Align.RIGHT; typeface = Typeface.DEFAULT_BOLD
    }
    private val titlePaint = paint(Color.WHITE).apply {
        textSize = 16f * dp; textAlign = Paint.Align.RIGHT; typeface = Typeface.DEFAULT_BOLD
    }
    private val subPaint = paint(Color.parseColor("#ECEFF1")).apply {
        textSize = 14f * dp; textAlign = Paint.Align.RIGHT
    }
    private val hintPaint = paint(Color.parseColor("#757575")).apply {
        textSize = 13f * dp; textAlign = Paint.Align.CENTER
    }
    private val glowPaint = paint(Color.WHITE)
    private val qPaint = paint(Color.BLACK).apply {
        textSize = 18f * dp; textAlign = Paint.Align.CENTER; typeface = Typeface.DEFAULT_BOLD
    }

    companion object {
        fun metalName(code: Int): String = when (code) {
            0 -> "آهن"
            1 -> "طلا"
            2 -> "نقره"
            3 -> "مس"
            4 -> "برنز"
            5 -> "آلومینیوم"
            else -> "نامشخص"
        }

        fun metalColor(code: Int): Int = Color.parseColor(
            when (code) {
                0 -> "#EF5350"
                1 -> "#FFD600"
                2 -> "#ECEFF1"
                3 -> "#FF7043"
                4 -> "#CD7F32"
                5 -> "#B0BEC5"
                else -> "#26C6DA"
            }
        )

        /** تبدیل عدد به ارقام فارسی */
        fun fa(n: Int): String =
            n.toString().map { if (it in '0'..'9') '۰' + (it - '0') else it }.joinToString("")
    }

    /** به‌روزرسانی صحنه. depth و size بر حسب سانتی‌متر. */
    fun update(hasTarget: Boolean, metal: Int, depth: Int, size: Int, estimated: Boolean) {
        this.hasTarget = hasTarget
        this.metalCode = metal
        this.depthCm = depth
        this.sizeCm = size
        this.sizeEstimated = estimated
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val g = h * 0.38f // خط سطح زمین

        c.drawRect(0f, 0f, w, h, bgPaint)
        c.drawRect(0f, g, w, h, soilPaint)
        c.drawLine(0f, g, w, g, groundPaint)

        drawPerson(c, w, g)
        if (hasTarget) {
            drawTarget(c, w, h, g)
        } else {
            c.drawText("هدفی یافت نشد", w * 0.5f, g + 50f * dp, hintPaint)
        }
        drawInfo(c, w)
    }

    /** شخص سمت چپ که فلزیاب را روی زمین می‌برد */
    private fun drawPerson(c: Canvas, w: Float, g: Float) {
        val s = g / 9.5f
        val cx = w * 0.14f

        // سر
        c.drawCircle(cx, g - 8.3f * s, s * 0.9f, personFill)
        // تنه
        personPaint.strokeWidth = s * 1.6f
        c.drawLine(cx, g - 7.2f * s, cx, g - 3.6f * s, personPaint)
        // پاها
        personPaint.strokeWidth = s * 0.9f
        c.drawLine(cx, g - 3.6f * s, cx - 0.9f * s, g, personPaint)
        c.drawLine(cx, g - 3.6f * s, cx + 1.1f * s, g, personPaint)
        // بازوی پشتی
        personPaint.strokeWidth = s * 0.7f
        c.drawLine(cx, g - 6.6f * s, cx - 0.9f * s, g - 4.2f * s, personPaint)
        // بازوی جلویی تا دست
        val hx = cx + 2.9f * s
        val hy = g - 4.8f * s
        c.drawLine(cx, g - 6.6f * s, hx, hy, personPaint)

        // دسته و کویل فلزیاب
        val kx = cx + 5.6f * s
        val ky = g - 0.7f * s
        shaftPaint.strokeWidth = s * 0.3f
        c.drawLine(hx, hy, kx, ky, shaftPaint)
        // ناحیهٔ جاروب روی زمین
        c.drawOval(RectF(kx - 3.5f * s, g - 1.3f * s, kx + 3.5f * s, g + 1.3f * s), scanPaint)
        coilPaint.strokeWidth = s * 0.35f
        c.drawOval(RectF(kx - 2f * s, ky - 0.7f * s, kx + 2f * s, ky + 0.7f * s), coilPaint)
    }

    /** شکل فلز زیر زمین + خط‌کش عمق */
    private fun drawTarget(c: Canvas, w: Float, h: Float, g: Float) {
        val tx = w * 0.5f
        val maxPx = h - g - 14f * dp // فضای زیر زمین برای ۶۰۰ سانتی‌متر
        val hasDepth = depthCm in 1..600
        val d = if (hasDepth) depthCm.coerceIn(20, 600) else 0
        val ty = if (hasDepth) g + maxPx * d / 600f else g + 40f * dp
        val r = (12f + 40f * (sizeCm.coerceIn(2, 80) / 80f)) * dp
        val color = metalColor(metalCode)

        glowPaint.color = (color and 0x00FFFFFF) or 0x44000000
        c.drawCircle(tx, ty, r * 1.5f, glowPaint)
        drawShape(c, tx, ty, r, metalCode, color)

        if (hasDepth) {
            drawRuler(c, w, g, maxPx, ty, tx + r, d)
        } else {
            c.drawText("عمق نامشخص", tx, ty + r + 16f * dp, hintPaint)
        }
    }

    private fun drawShape(c: Canvas, x: Float, y: Float, r: Float, code: Int, color: Int) {
        val fill = paint(color)
        val edge = paint(Color.parseColor("#66000000"), Paint.Style.STROKE, r * 0.1f)
        val inner = paint(Color.parseColor("#66FFFFFF"), Paint.Style.STROKE, r * 0.08f)
        when (code) {
            1, 2 -> { // سکه: طلا / نقره
                c.drawCircle(x, y, r, fill)
                c.drawCircle(x, y, r * 0.95f, edge)
                c.drawCircle(x, y, r * 0.65f, inner)
            }
            3 -> { // مس: بیضی
                val rect = RectF(x - r, y - r * 0.6f, x + r, y + r * 0.6f)
                c.drawOval(rect, fill)
                c.drawOval(rect, edge)
            }
            0 -> { // آهن: قطعهٔ نامنظم
                val p = Path()
                for (i in 0 until 8) {
                    val a = Math.toRadians(i * 45.0)
                    val rr = r * (0.7f + 0.3f * ((i * 37) % 5) / 4f)
                    val px = x + rr * cos(a).toFloat()
                    val py = y + rr * 0.75f * sin(a).toFloat()
                    if (i == 0) p.moveTo(px, py) else p.lineTo(px, py)
                }
                p.close()
                c.drawPath(p, fill)
                c.drawPath(p, edge)
            }
            4 -> { // برنز: حلقه
                val ring = paint(color, Paint.Style.STROKE, r * 0.45f)
                c.drawCircle(x, y, r * 0.7f, ring)
            }
            5 -> { // آلومینیوم: ورق نازک
                val rect = RectF(x - r, y - r * 0.35f, x + r, y + r * 0.35f)
                c.drawRoundRect(rect, r * 0.2f, r * 0.2f, fill)
                c.drawRoundRect(rect, r * 0.2f, r * 0.2f, edge)
            }
            else -> { // نامشخص: لوزی با علامت سؤال
                val p = Path()
                p.moveTo(x, y - r)
                p.lineTo(x + r, y)
                p.lineTo(x, y + r)
                p.lineTo(x - r, y)
                p.close()
                c.drawPath(p, fill)
                c.drawPath(p, edge)
                c.drawText("?", x, y + 6f * dp, qPaint)
            }
        }
    }

    /** خط‌کش عمودی سمت راست از سطح زمین تا هدف */
    private fun drawRuler(c: Canvas, w: Float, g: Float, maxPx: Float, ty: Float, targetRight: Float, d: Int) {
        val rx = w * 0.9f
        c.drawLine(rx, g, rx, ty, rulerPaint)

        var cm = 0
        while (cm <= d) {
            val y = g + maxPx * cm / 600f
            val major = cm % 100 == 0
            val len = if (major) 10f * dp else 5f * dp
            c.drawLine(rx - len, y, rx, y, rulerPaint)
            if (major) c.drawText(fa(cm), rx - 14f * dp, y + 4f * dp, labelPaint)
            cm += 50
        }

        // خط افقی از هدف تا خط‌کش
        c.drawLine(targetRight + 4f * dp, ty, rx, ty, dashPaint)
        // عدد عمق زیر خط افقی
        c.drawText("${fa(d)} cm", rx - 4f * dp, ty + 20f * dp, depthLabelPaint)
    }

    /** نوع فلز و ابعاد: بالا سمت راست */
    private fun drawInfo(c: Canvas, w: Float) {
        val x = w - 12f * dp
        val name = if (hasTarget) metalName(metalCode) else "—"
        titlePaint.color = if (hasTarget) metalColor(metalCode) else Color.GRAY
        c.drawText("نوع فلز: $name", x, 26f * dp, titlePaint)

        val sizeText = when {
            !hasTarget -> "—"
            sizeCm > 0 && sizeEstimated -> "حدود ${fa(sizeCm)} سانتی‌متر (تخمینی)"
            sizeCm > 0 -> "${fa(sizeCm)} سانتی‌متر"
            else -> "نامشخص"
        }
        c.drawText("ابعاد فلز: $sizeText", x, 50f * dp, subPaint)
    }
}
