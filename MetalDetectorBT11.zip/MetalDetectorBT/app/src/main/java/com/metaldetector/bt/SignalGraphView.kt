package com.metaldetector.bt

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View

/** نمودار زنده قدرت سیگنال (آخرین ۱۰۰ نمونه، ۰ تا ۱۰۰۰) */
class SignalGraphView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    private val data = ArrayDeque<Int>()
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#FFB300"); strokeWidth = 5f
        style = Paint.Style.STROKE
    }
    private val gridPaint = Paint().apply {
        color = Color.parseColor("#2A2A2A"); strokeWidth = 1.5f
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#757575"); textSize = 24f
    }

    fun push(v: Int) {
        if (data.size >= 100) data.removeFirst()
        data.addLast(v.coerceIn(0, 1000))
        invalidate()
    }

    fun clear() { data.clear(); invalidate() }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat(); val h = height.toFloat()
        // خطوط شبکه
        for (i in 1..3) {
            val y = h * i / 4f
            canvas.drawLine(0f, y, w, y, gridPaint)
        }
        canvas.drawText("1000", 8f, 28f, textPaint)
        canvas.drawText("0", 8f, h - 8f, textPaint)
        if (data.size < 2) return
        val stepX = w / 99f
        var prevX = w - (data.size - 1) * stepX
        var prevY = h - (data.first() / 1000f) * h
        var idx = 0
        for (v in data) {
            if (idx > 0) {
                val x = prevX + stepX
                val y = h - (v / 1000f) * h
                canvas.drawLine(prevX, prevY, x, y, linePaint)
                prevX = x; prevY = y
            }
            idx++
        }
    }
}
