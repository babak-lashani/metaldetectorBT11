# ProGuard rules (release بدون obfuscation خاص)
-keep class com.metaldetector.bt.** { *; }
