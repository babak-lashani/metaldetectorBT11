/* ============================================================
 * نمونه کد STM32F105 — ارسال داده فلزیاب به موبایل از طریق HC-05
 * اتصال سخت‌افزاری:
 *   HC-05 VCC  -> 5V (یا 3.3V بسته به ماژول، معمولاً 5V)
 *   HC-05 GND  -> GND
 *   HC-05 TXD  -> PA10 (USART1_RX میکرو)  — حتماً مقسم ولتاژ/مبدل سطح اگر 5V است
 *   HC-05 RXD  -> PA9  (USART1_TX میکرو) از طریق مقسم ولتاژ به 3.3V
 *   نرخ پیش‌فرض HC-05: 9600,8N1
 *
 *  این فایل را به پروژه STM32CubeIDE خود اضافه کنید.
 *  تابع MetalDetector_BT_Send() را هر 200~300 میلی‌ثانیه صدا بزنید.
 * ============================================================ */
#include "usart.h"
#include <stdio.h>
#include <string.h>

/* کدهای نوع فلز — باید با اپ اندروید یکی باشد */
#define METAL_IRON     0
#define METAL_GOLD     1
#define METAL_SILVER   2
#define METAL_COPPER   3
#define METAL_BRONZE   4
#define METAL_ALU      5
#define METAL_UNKNOWN  9

extern UART_HandleTypeDef huart1;  // همان UART متصل به HC-05

/* ارسال یک پکت JSON با \n در انتها.
 * مثال خروجی: {"vdi":72,"sig":850,"depth":145,"size":18,"metal":1}\n
 *   vdi   : عدد VDI دستگاه شما (مثلاً -95 تا +95 یا هر مقیاس خودتان)
 *   sig   : قدرت سیگنال / خط حساسیت 0 تا 1000
 *   depth : عمق تقریبی به سانتی‌متر 20 تا 600 (اگر نامعتبر است 0 بفرستید)
 *   size  : اندازه تقریبی هدف به سانتی‌متر (قطر تخمینی). اگر ندارید 0
 *   metal : یکی از METAL_* بالا
 */
void MetalDetector_BT_Send(int vdi, int sig, int depth_cm, int size_cm, int metal)
{
    char buf[128];
    if (sig < 0) sig = 0; if (sig > 1000) sig = 1000;
    if (depth_cm < 0) depth_cm = 0; if (depth_cm > 600) depth_cm = 600;
    int len = snprintf(buf, sizeof(buf),
        "{\"vdi\":%d,\"sig\":%d,\"depth\":%d,\"size\":%d,\"metal\":%d}\n",
        vdi, sig, depth_cm, size_cm, metal);
    if (len > 0) {
        HAL_UART_Transmit(&huart1, (uint8_t*)buf, (uint16_t)len, 100);
    }
}

/* مثال استفاده در حلقه اصلی:
 *
 *   int vdi   = current_vdi;          // از الگوریتم خودتان
 *   int sig   = proximity_1_to_1000;  // همان خط حساسیت 1 تا 1000 روی LCD
 *   int depth = estimated_depth_cm;   // 20 تا 600، وگرنه 0
 *   int size  = estimated_size_cm;    // قطر تخمینی، وگرنه 0
 *   int metal = METAL_GOLD;           // از تفکیک صوتی/آهن‌زدایی خودتان
 *   MetalDetector_BT_Send(vdi, sig, depth, size, metal);
 *   HAL_Delay(250);
 *
 * نکته: اگر از printf با UART استفاده می‌کنید، کافیست همین رشته JSON را
 * با printf ارسال کنید. مهم این است که هر پیام با \n تمام شود.
 */
